PyDev.Debugger
==============

[![Build Status](https://travis-ci.org/fabioz/PyDev.Debugger.png)](https://travis-ci.org/fabioz/PyDev.Debugger)

This repository contains the sources for the Debugger used in PyDev & PyCharm.

It should be compatible with Python 2.4 onwards (as well as Jython 2.2.1, IronPython and PyPy -- and any
other variant which properly supports the Python structure for debuggers -- i.e.: sys.settrace/threading.settrace).